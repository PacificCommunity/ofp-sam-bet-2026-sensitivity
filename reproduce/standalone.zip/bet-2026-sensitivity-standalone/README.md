# BET 2026 sensitivity saved models

17 original final PARs, native inputs, fitting scripts and reference values.

```sh
make list
make verify
make rerun CASE=caal-0.5-sub-basin OUT=/absolute/new-folder
```

`verify` and `prepare` use base R and system hash/archive tools. Native `rerun`
requires Linux x86-64. It evaluates the saved PAR with ceiling 1, requires the
reported iteration and function counter to be 0. Evaluation uses convergence
flag `1 50 0` (criterion 1) and checks the original objective, per-model
parameter count, dimensions and central values.
Detailed generated outputs remain in OUT. Use `CASE=all` for all cases.

`make refit` runs the original `doitall.sh` from its saved inputs in a new
folder. This longer full fit is not part of the saved-PAR checks. Models with
unresolved script dependencies refuse refitting; see `models.csv`.

`FILES.csv` binds every native file, including the shared engines; `models.csv`
binds each PAR and reference to its case. Historical externally executed
engine identities remain unconfirmed. Published results are unchanged.
